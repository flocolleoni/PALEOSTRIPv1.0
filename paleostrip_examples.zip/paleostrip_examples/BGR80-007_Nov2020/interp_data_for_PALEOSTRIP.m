%--------------------------------------------------------------------------
% PALEOSTRIP PRE-PROCESSING
%
% Pre-Processing input data 2D section
%
% This script re-interpolates horizons to the longest one: all files might
% not have the same length, but PALEOSTRIP only accept arrays of the same
% length.
%
% This file also allows to interpolate to a different array resolution or
% to remain on the original longest array.
%
% Input files: two-columns (X depth)
% X = cartesian coordinate in meters
% depth = meters;
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% HOW TO USE THIS SCRIPT:
%
% 1- Set Interpolation options, Input directory and files, output files
%
% 2- Run the script
%
% 3- Outputs are written in the same directory as input files
%--------------------------------------------------------------------------

%
% Interpolation option
%--------------------------------------------------------------------------
% 1 = interpolation to at a different resolution;
% 0 = no interpolation (remains on original coordinates)
opt_interp = 1;
dx=1000; % chosen grid resolution (in meters)
%
% Input directory and files:
%--------------------------------------------------------------------------
nb_files=10; % Number of input files
foldername='/Users/flo/Recherche/OGS/Laura/Backstripping_code/Fortran_Flo/back2D/MATLAB_code/dati/BGR80-007_Nov2020';
dfiles(1).name='./original/BGR80_01_basement.dat';
dfiles(2).name='./original/BGR80_02_RSU6.dat';
dfiles(3).name='./original/BGR80_03_RSU5B.dat';
dfiles(4).name='./original/BGR80_04_RSU5A.dat';
dfiles(5).name='./original/BGR80_05_RSU5.dat';
dfiles(6).name='./original/BGR80_06_RSU4.dat';
dfiles(7).name='./original/BGR80_07_RSU3.dat';
dfiles(8).name='./original/BGR80_08_RSU2.dat';
dfiles(9).name='./original/BGR80_09_RSU1.dat';
dfiles(10).name='./original/BGR80_10_bathymetry.dat';

% Output files names
%--------------------------------------------------------------------------
outfiles(1).name='BGR80_01_basement_interp_1km_index.dat';
outfiles(2).name='BGR80_02_RSU6_interp_1km_index.dat';
outfiles(3).name='BGR80_03_RSU5B_interp_1km_index.dat';
outfiles(4).name='BGR80_04_RSU5A_interp_1km_index.dat';
outfiles(5).name='BGR80_05_RSU5_interp_1km_index.dat';
outfiles(6).name='BGR80_06_RSU4_interp_1km_index.dat';
outfiles(7).name='BGR80_07_RSU3_interp_1km_index.dat';
outfiles(8).name='BGR80_08_RSU2_interp_1km_index.dat';
outfiles(9).name='BGR80_09_RSU1_interp_1km_index.dat';
outfiles(10).name='BGR80_10_bathymetry_interp_1km_index.dat';
%
% END OF USER PROVIDED FILES NAMES AND INTERPOLATION OPTION
%--------------------------------------------------------------------------




%-------- BEGINNING OF THE SCRIPT -----------------------------------------

% Get input files names
%-----------------------
cfilenames={};
for ii=1:length(dfiles)
    cfilenames{ii}=dfiles(ii).name; %#ok grow
end
cfilenames=sort(cfilenames);


% Get the lenght of the longest horizons
%----------------------------------------
delimiterIn = ' ';
format long g
max_file=0;
for ii=1:nb_files
    fid=fopen(fullfile(foldername,cfilenames{ii}));
    if fid <0
        %disp(['Unable to open file ' fullfile(foldername,cfilenames{ii}) '.'])
        outputstring=['Unable to open file ' fullfile(foldername,cfilenames{ii}) '.'];
        M=[];
        return
    end

    % check number of columns
    tline = fgetl(fid);
    number_of_columns=length(str2num(tline));
    fseek(fid,0,-1); %rewind the file

    % Import data
    data=importdata(fullfile(foldername,cfilenames{ii}),delimiterIn);

    % Determine input file size
    dlength=size(data,1);

    if (dlength > max_file)
       max_file = dlength;
       file_number = ii;
    end

end


% Interpolate input files to the longest coordinates array (given by file_number)
%---------------------------------------------------------------------------------

% Import data from longest file
data_longest=importdata(fullfile(foldername,cfilenames{file_number}),delimiterIn);

% Select only unique coordinates (avoid repetitive coordinates)
[x_longest, index]=unique(data_longest(:,1));

% Interpolate data
figure
for ii=1:nb_files

% Import data
data=importdata(fullfile(foldername,cfilenames{ii}),delimiterIn);

% Select only unique coordinates (avoid repetitive coordinates)
[xdata, index]=unique(data(:,1));
orig_data=data(:,2);

%Interpolate to longest array
if (opt_interp == 0)
  data_new = interp1(xdata,orig_data(index),x_longest,'linear','extrap');

%Interpolate to user chosen resolution
else
  xmin=min(x_longest); xmax=max(x_longest);
  x_min=dx*round(xmin/dx); % Round to the nearest interger multiple of dx
  x_max=dx*round(xmax/dx); % Round to the nearest interger multiple of dx
  xnew=x_min:dx:x_max;     % New X array

  dx_pos=round(dx/1000);
  xpos=1:dx_pos:length(xnew)*dx_pos;
  
  data_new = interp1(xdata,orig_data(index),xnew,'linear','extrap');

  data_new=data_new';
  xnew=xnew';
  xpos=xpos';
end

% Plot interpolated data
plot(xnew,-data_new); hold on

% Save interpolated data
filename=outfiles(ii).name;
fid = fopen(fullfile(foldername,filename),'w');

%formatstring=['%6.6f' repmat(' %4.4f',1,size(data_new,2)) '\n'];
formatstring=['%4d' repmat(' %4.4f',1,size(data_new,2)) '\n'];
fprintf(fid,formatstring,[xpos, data_new(:,1)]');
fclose(fid);

end
